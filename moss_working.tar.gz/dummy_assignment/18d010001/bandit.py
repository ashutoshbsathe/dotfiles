# Author: Ashutosh Sathe (21Q050012)
from argparse import ArgumentParser, ArgumentTypeError
from types import SimpleNamespace
import numpy as np 
"""
Bandit algorithms
"""
def epsilon_greedy(bandit, epsilon, horizon):
    bandit.greedy_wrt = 'p_hat_a'
    bandit.update_optimal()
    reward = 0.
    for _ in range(horizon):
        if np.random.rand() < epsilon:
            reward += bandit.explore()
        else:
            bandit.update_optimal()
            reward += bandit.exploit()
    return reward 

def ucb(bandit, scale, horizon):
    # All the arms will be pulled once to get nonzero u_a
    for i in range(bandit.n_arms):
        bandit.pull(i)
    bandit.greedy_wrt = 'ucb_a'
    reward = 0
    # Update after Ishan's comment
    for t in range(1, horizon + 1 - bandit.n_arms):
        for i in range(bandit.n_arms):
            bandit.arms[i].ucb_a = bandit.arms[i].p_hat_a + (scale * np.log(t) / (bandit.arms[i].s_a + bandit.arms[i].f_a)) ** 0.5
        bandit.update_optimal()
        reward += bandit.exploit()
    return reward

def find_q(p_hat, u_a, t, c=3, precision=1e-6, max_iter=1000, eps=1e-10):
    """
    Find q for KL-UCB using binary search as disucssed in lecture
    """
    p_hat = min(max(p_hat, eps), 1-eps)
    lower = p_hat
    upper = 1. 
    itr = 0
    q = lower 
    while itr < max_iter and upper - q > precision:
        q = (lower + upper) * 1. / 2
        q = min(max(q, eps), 1-eps) # Ensures non zero thingies so that numpy doesn't cry
        kl = p_hat * np.log(p_hat / q) + (1 - p_hat) * np.log((1 - p_hat) / (1 - q))
        rhs = np.log(t) + c * np.log(np.log(t))
        if u_a * kl > rhs:
            upper = q
        else:
            lower = q
        itr += 1 

    return (lower + upper) * 1. / 2

def kl_ucb(bandit, horizon, c=3):
    bandit.greedy_wrt = 'kl_ucb_a'
    # Pull randomly twice so that ln(ln(t)) is always well defined 
    bandit.explore()
    bandit.explore()
    reward = 0
    for t in range(3, horizon+1):
        for i in range(bandit.n_arms):
            bandit.arms[i].kl_ucb_a = find_q(
                bandit.arms[i].p_hat_a, 
                bandit.arms[i].s_a + bandit.arms[i].f_a, 
                t, c 
            )
        bandit.update_optimal()
        reward += bandit.exploit()
    return reward 

def thompson_sampling(bandit, horizon):
    # No need for sampling every arm at least once
    bandit.greedy_wrt = 'x_a'
    reward = 0
    for t in range(1, horizon+1):
        for i in range(bandit.n_arms):
            bandit.arms[i].x_a = np.random.beta(bandit.arms[i].s_a+1, bandit.arms[i].f_a+1)
        bandit.update_optimal()
        reward += bandit.exploit()
    return reward 

"""
Argument parsing
"""
def check_non_negative_int(val):
    val = int(val)
    if val < 0:
        raise ArgumentTypeError(f'Expected non-negative integer, got {val}')
    return val

def check_fraction(val):
    val = float(val)
    if val < 0 or val > 1:
        raise ArgumentTypeError(f'Expected argument to be within [0, 1], got {val}')
    return val

def check_non_negative_float(val):
    val = float(val)
    if val < 0:
        raise ArgumentTypeError(f'Expected non-negative integer, got {val}')
    return val 

def parse_args():
    parser = ArgumentParser()
    parser.add_argument('--instance', help='Path to the instance file', type=str, required=True)
    parser.add_argument('--algorithm', help='Algorithm', type=str, choices=['epsilon-greedy-t1', 'ucb-t1', 'kl-ucb-t1', 'thompson-sampling-t1', 'ucb-t2', 'alg-t3', 'alg-t4'], required=True)
    parser.add_argument('--randomSeed', help='Seed for RNG. Must be non-negative', type=check_non_negative_int, default=0)
    parser.add_argument('--epsilon', help='Epsilon, must be between [0, 1]', type=check_fraction, default=0.02)
    parser.add_argument('--scale', help='Scale for task 2', type=check_non_negative_float, default=2)
    parser.add_argument('--threshold', help='Threshold for task 4', type=check_fraction, default=0)
    parser.add_argument('--horizon', help='Horizon, must be non-negative', type=check_non_negative_int, default=1)
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_args()
    np.random.seed(args.randomSeed)
    bandit = Bandit(**read_instance(args.instance, support=args.algorithm.endswith('t3') or args.algorithm.endswith('t4')))
    if args.algorithm == 'epsilon-greedy-t1':
        reward = epsilon_greedy(bandit, args.epsilon, args.horizon)
    elif args.algorithm == 'ucb-t1' or args.algorithm == 'ucb-t2':
        reward = ucb(bandit, args.scale, args.horizon)
    elif args.algorithm == 'kl-ucb-t1':
        reward = kl_ucb(bandit, args.horizon, c=3)
    elif args.algorithm == 'thompson-sampling-t1':
        reward = thompson_sampling(bandit, args.horizon)
    elif args.algorithm == 'alg-t3':
        reward = kl_ucb(bandit, args.horizon, c=3)
    elif args.algorithm == 'alg-t4':
        bandit.threshold = args.threshold
        t4_highs = thompson_sampling(bandit, args.horizon)
    if 'reward' in locals():
        regret = bandit.max_expected_reward(args.horizon) - reward 
    else:
        regret = 0.
    if 't4_highs' in locals():
        highs = t4_highs
        regret = bandit.max_expected_highs(args.horizon) - highs
    else:
        highs = 0
    line = f'{args.instance},{args.algorithm},{args.randomSeed},{args.epsilon},{args.scale},{args.threshold},{args.horizon},{regret:.3f},{highs:.3f}'
    print(line)
