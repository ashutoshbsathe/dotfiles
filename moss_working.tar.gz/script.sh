#!/bin/sh 

# ASSIGN_DIR/<rollno>/ASSIGN_FNAME

ASSIGN_DIR="dummy_assignment"
ASSIGN_FNAME="bandit.py"
OUT_DIR="moss_${ASSIGN_DIR}_${ASSIGN_FNAME}"
TIMESTAMP=$(date +%F.%H-%M-%S)

mkdir -p $OUT_DIR
./moss -d $ASSIGN_DIR/*/$ASSIGN_FNAME 2>&1 | tee $OUT_DIR/moss.$TIMESTAMP.log 

RESULTS_URL=$(tail -n 1 $OUT_DIR/moss.$TIMESTAMP.log)
# moss.stanford.edu/results/<x>/<y> -- useful to store both <x> and <y>
wget -r -np -nH --cut-dirs=1 -P $OUT_DIR/ -e robots=off $RESULTS_URL
